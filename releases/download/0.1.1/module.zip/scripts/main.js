Hooks.once('diceSoNiceInit', (dice3d) => {
    dice3d.addTexture("Ps2 Majima", {
        name: "Ps2 Majima",
        composite: "source-over",
        source: "modules/PS2-Majima-Dice/images/majeng.png",
        bump:"modules/PS2-Majima-Dice/images/majeng.png"
    });

});
